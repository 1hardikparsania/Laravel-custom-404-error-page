
<html>

<body>


   
        <div >
          <h1 >Custom 404 Error in Laravel</h1>
        
        <p><strong>Page you want is not on this web site</strong></p>
         
    
</div>

<img height="420" width="420" src="{{url('/images/error404.png')}}" >

</body>

</html>