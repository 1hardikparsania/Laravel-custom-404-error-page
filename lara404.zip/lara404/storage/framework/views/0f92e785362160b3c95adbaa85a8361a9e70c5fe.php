
<html>

<body>


   
        <div >
          <h1 >Custom 404 Error in Laravel</h1>
        
        <p><strong>Page you want is not on this web site</strong></p>
         
    
</div>

<img height="420" width="420" src="<?php echo e(url('/images/error404.png')); ?>" >

</body>

</html>
<?php /* /Users/hardikparsania_mac/Desktop/web_demonuts/lara404/lara404/resources/views/errors/404.blade.php */ ?>